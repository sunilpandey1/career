<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\User;
use Session;
use Validator;
use Auth;
use Hash;
use DB;
class UserController extends Controller
{
	
    /**
     * Show the profile for the given user.
     *
     * @param  int  $id
     * @return View
     */
   public function login(){
        $uname = Input::get('username');
        $password = Input::get('password');
            if (Auth::attempt(array('username' => $uname, 'password' => $password))){
             return redirect('/dashboard/');
            }
            else {  
				Session::flash('message', 'Wrong Credentials !');
                return redirect('/login');
            }
       }
   
	public function store(Request $request)
   {
    $profile = new User;
    $profile->username = $request->username;
	$password = bcrypt($request->password);
    $profile->password = $password;
    $profile->name = $request->name;
	$profile->mobile = $request->mobile;
	$profile->email = $request->email;
    $profile->save();
	Session::flash('message', 'Successfully Saved!');
	 return redirect('/signup');
   }
   public function adminlogin(){
        $uname = Input::get('username');
        $password = Input::get('password');
		
            if (Auth::attempt(array('username' => $uname, 'password' => $password))){
				
             return redirect('/admin/index');
            }
            else {  
				Session::flash('message', 'Wrong Credentials !');
                return redirect('/admin/');
            }
       }
	public function enquiry(Request $request)
	{
		$insert=DB::insert('insert into enquirys (name,mobile,email,class_name,address) values (?, ?,?, ?,?)', [$request->name,$request->mobile,$request->email,$request->class_name,$request->address,]);
		Session::flash('message', 'Successfully Saved!');
		
		 return redirect('/dashboard/enquiry');
	}
	public function resources(Request $request)
	{
		$insert=DB::insert('insert into resources (page_name,content) values (?, ?)', [$request->page_name,$request->content]);
		Session::flash('message', 'Successfully Saved!');
		
		 return redirect('/admin/resources');
	}
	public function getresource(Request $request)
	{
		 $resource = DB::table('resources')->where('page_name',$request->page)->first();
	//dd($resource);
		  return view('resources', ['resource' => $resource]);
	}
	public function view_resources(Request $request)
	{
		 $resource = DB::table('resources')->get();
	//dd($resource);
		  return view('admin.view-resources', ['resource' => $resource]);
	}
	public function destroy_resources($id) {
      DB::delete('delete from resources where id = ?',[$id]);
      Session::flash('message', 'Deleted Successfully!');
		
		 return redirect('/admin/view-resources');
   }
	public function counselling(Request $request)
	{
		//dd($request);
		$image1="";
		$image2="";
		$image3="";
		$image4="";
		$image5="";
		$image6="";
		$image7="";
		$image8="";
		$image9="";
		$image10="";
		$cover = $request->file('image1');
		if($cover)
		$image1= $cover->getClientOriginalName();
		$cover2 = $request->file('image2');
		if($cover2)
		$image2= $cover2->getClientOriginalName();
		$cover3 = $request->file('image3');
		if($cover3)
		$image3= $cover3->getClientOriginalName();
		$cover4 = $request->file('image4');
		if($cover4)
		$image4= $cover4->getClientOriginalName();
		$cover5 = $request->file('image5');
		if($cover5)
		$image5= $cover5->getClientOriginalName();
		$cover6 = $request->file('image6');
		if($cover6)
		$image6= $cover6->getClientOriginalName();
		$cover7 = $request->file('image7');
		if($cover7)
		$image7= $cover7->getClientOriginalName();
		$cover8 = $request->file('image8');
		if($cover8)
		$image8= $cover8->getClientOriginalName();
		$cover9 = $request->file('image9');
		if($cover9)
		$image9= $cover9->getClientOriginalName();
		$cover10 = $request->file('image10');
		if($cover10)
		$image10= $cover10->getClientOriginalName();
		$insert=DB::insert('insert into counsellings (page_title,content,image1,image2,image3
		,image4,image5,image6,image7,image8,image9,image10) values (?, ?,?, ?,?, ?,?, ?,?, ?,?, ?)', [$request->page_name,$request->content,$image1,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10]);
		//$file = $request->file('product_image') ;
            
           if($cover){
            $destinationPath = public_path().'/images/' ;
            $cover->move($destinationPath,$image1);
		   }
		   if($cover2){
            $destinationPath = public_path().'/images/' ;
            $cover2->move($destinationPath,$image2);
		   }
		   if($cover3){
            $destinationPath = public_path().'/images/' ;
            $cover3->move($destinationPath,$image3);
		   }
		   if($cover4){
            $destinationPath = public_path().'/images/' ;
            $cover4->move($destinationPath,$image4);
		   }
		   if($cover5){
            $destinationPath = public_path().'/images/' ;
            $cover5->move($destinationPath,$image5);
		   }
		   if($cover6){
            $destinationPath = public_path().'/images/' ;
            $cover6->move($destinationPath,$image6);
		   }
		   if($cover7){
            $destinationPath = public_path().'/images/' ;
            $cover7->move($destinationPath,$image7);
		   }
		   if($cover8){
            $destinationPath = public_path().'/images/' ;
            $cover8->move($destinationPath,$image8);
		   }
		   if($cover9){
            $destinationPath = public_path().'/images/' ;
            $cover9->move($destinationPath,$image9);
		   }
		   if($cover10){
            $destinationPath = public_path().'/images/' ;
            $cover10->move($destinationPath,$image10);
		   }
		/* if($image1)
		 $path1 = $request->file('image1')->store('photos');
		if($image2)
		$path2 = $request->file('image2')->store('photos');
		if($image3)
		$path3 = $request->file('image3')->store('photos');
		if($image4)
		$path4 = $request->file('image4')->store('photos');
		if($image5)
		$path5 = $request->file('image5')->store('photos');
		if($image6)
		$path6 = $request->file('image6')->store('photos');
		if($image7)
		$path7= $request->file('image7')->store('photos');
		if($image8)
		$path8= $request->file('image8')->store('photos');
		if($image9)
		$path9= $request->file('image9')->store('photos');
		if($image10)
		$path10= $request->file('image10')->store('photos'); */
		Session::flash('message', 'Successfully Saved!');
		
		 return redirect('/admin/career-counselling');
	}
	public function getcounselling(Request $request)
	{
		 $counselling = DB::table('counsellings')->where('page_title',$request->page)->get();
	//dd($counselling);
		  return view('career-counselling', ['counselling' => $counselling]);
	}
	public function view_counselling(Request $request)
	{
		 $counselling = DB::table('counsellings')->get();
	//dd($resource);
		  return view('admin.view-career-counselling', ['counselling' => $counselling]);
	}
	public function destroy_counselling($id) {
      DB::delete('delete from counsellings where id = ?',[$id]);
      Session::flash('message', 'Deleted Successfully!');
		
		 return redirect('/admin/view-career-counselling');
   }
}