<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title> Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="{{asset('/css/main.css')}}">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    
    <!-- Sidebar menu-->
    @include('dashboard.include.header')
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>  Enquiry</h1>
          <p></p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Enquiry</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
				<div class="panel">
					<div class="panel-body">
					  <h4 class="panel-title">Enquiry</h4><hr>
					  @if(Session::has('message'))
			<p class="alert-success">{{ Session::get('message') }}</p>
		 @endif
					 <form method="post" action="{{ url('/enquiry') }}">
					 <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
						
						<div class="form-group">
							<div class="col-md-6">
							  <input type="text" placeholder="name" title="Enter Your name" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips name" name="name"   required >
							</div>
						 </div>
						<div class="form-group">
							<div class="col-md-6">
							  <input type="text" placeholder="Enter your mobile number" title="Enter your mobile number" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips mobile_number" name="mobile"   required >
							</div>
						 </div>
						<div class="form-group">
							<div class="col-md-6">
							  <input type="text" placeholder="Enter your email" title="Enter your email" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips email" name="email"   required >
							</div>
						 </div>
						<div class="form-group">
							<div class="col-md-6">
							  <select name="class_name" required class="form-control">
								  <option value="">Select class</option>
								  <option value="8">8</option>
								  <option value="9">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
							  </select>
							</div>
						 </div>
						 <div class="form-group">
							<div class="col-md-6">
							  <textarea cols="6" rows="5" name="address" placeholder="Address" class="form-control" required></textarea>
							</div>
						 </div>
						 <div class="form-group">
							<div class="col-md-4">
							 
							  <button type="submit" name="enquiry" class="btn btn-primary product">Add Enquiry</button>
							 </div>
						</div>
				
						 
						 </form>
					  </div>
					</div>
			</div>
          </div>
        </div>
      </div>
	   
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
  </body>
</html>