<?php
session_start();
require_once('include/connection.php');
error_reporting(0);
if(empty($_SESSION['email']))
{
	echo "<script>window.location.href = 'login.php';</script>";
}

if(isset($_POST['add_stock']))
{

	$product_name=$_POST['product_name'];
	$p_name=explode("??",$product_name);
	$p_id=$p_name[0];
	$prd_name=$p_name[1];
	$particulars=$_POST['particulars'];
	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	$remarks=$_POST['remarks'];
	$sql="insert into stock(product_id,product_name,particulars,quantity,rate,remarks) values('$p_id','$prd_name','$particulars','$quantity','$price','$remarks')";
	
	$result=mysqli_query($connect,$sql);
	 
	$check_stoc="select * from main_stock where product_id='$p_id'";
	
	$check_run=mysqli_query($connect,$check_stoc);
	$check_num=mysqli_num_rows($check_run);
	$check_result=mysqli_fetch_array($check_run);
	if($check_num)
	{
		$org_quantity=$check_result['total_stock'];
		$tot_quantity=$org_quantity+$quantity;
		$update="update main_stock set total_stock='$tot_quantity' where product_id='$p_id'";
		//echo $tot_quantity;die;
	}
	else{
		$update="insert into main_stock(product_id,total_stock)values('$p_id','$quantity')";
	}
	//echo $update;die;
	$upd_run=mysqli_query($connect,$update);
	if($result)
	echo "<script>alert('successfully inserted')</script>";

	else
		echo "<script>alert('Oops Something went wrong!')</script>";
	
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title> Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	
<style>
  #myFileInput1 {
    display:none;
}
.pic_disp{
	height:100px;
	width:100px;
}
.rmv:before{content:"\f158";font-family:dashicons;display:block;position: relative;z-index: 1;background: #9d141b;color: #fff;border-radius: 30em;padding-top: 2px;width: 20px;height: 18px;float: right;top: 12px;text-align: center;cursor:pointer; pointer-events:auto;}
.upload_photo{width:58px;float:left;margin-right:20px;position:relative;}
.upload_photo:last-child{margin-right:0px;}
.upload_photo img{width:46px;height:46px;border:2px solid #fff;border-radius:3px;}
.mg{
	margin-top: 0px;
    font-size: 15px;
    font-weight: 600;
}
  </style>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    
    <!-- Sidebar menu-->
    <?php include_once('include/header.php')?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Add Stock</h1>
         
        </div>
		 
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Add Stock</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
			
	<form method="post">
      <div class="panel">
        <div class="panel-body">
          <h4 class="panel-title">Add New Stock</h4>
		  <p></p><p></p>
          <div class="row">
                <div class="col-sm-8">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name" required >
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				  
              </div>
          </div>
		</div><p></p>
	   <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <textarea placeholder="Particulars" rows="4" cols="10" title="Particulars" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips particulars" name="particulars" required ></textarea>
                 </div>   
              </div>
          </div>
		</div><p></p>
		 <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity" name="quantity" required >
                 </div>   
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="number" placeholder="Product Price in rupees" title="Product Price" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips price" name="price" required >
                 </div>   
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <textarea placeholder="Remarks" title="Remarks" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips remarks" name="remarks"  ></textarea>
                 </div>   
              </div>
          </div>
		</div>
		<p></p>
		<p></p>
		
	   
		
		
		<input  type="submit" name="add_stock" class="btn btn-primary stock" value="Add New Stock">
	</form>
			</div>
          </div>
        </div>
      </div>
	  <?php include('include/footer.php')?> 
    </main>
	 <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
</body>
</html>