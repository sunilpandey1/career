<?php
session_start();
require_once('include/connection.php');
error_reporting(0);
if(empty($_SESSION['email']))
{
	echo "<script>window.location.href = 'login.php';</script>";
}

if(isset($_POST['add_billing']))
{

	$product_name=$_POST['product_name'];
	$p_name=explode("??",$product_name);
	$p_id=$p_name[0];
	$prd_name=$p_name[1];
	$billing_no=$_POST['billing_no'];
	$supplied_quantity=$_POST['quantity'];
	$unit_price=$_POST['price'];
	$total_price=$supplied_quantity*$unit_price;
	$tax=$_POST['tax'];
	$image=$_FILES["pic"]["name"];
	//echo $image;die;
	$query=mysqli_query($connect,"select max(id) as pid from billing");
	$result=mysqli_fetch_array($query);
	 $productid=$result['pid']+1;
	$dir="images/$productid";
	if (!file_exists($dir)) {
	mkdir($dir);
	}
	move_uploaded_file($_FILES["pic"]["tmp_name"],"images/$productid/".$_FILES["pic"]["name"]);
	
	    if($image!="")
		$sql="insert into billing(billing_no,product_id,product_name,supplied_quantity,unit_price,total_price,tax,image) values('$billing_no','$p_id','$prd_name','$supplied_quantity','$unit_price','$total_price','$tax','$image')";
	    else
	    	$sql="insert into billing(billing_no,product_id,product_name,supplied_quantity,unit_price,total_price,tax) values('$billing_no','$p_id','$prd_name','$supplied_quantity','$unit_price','$total_price','$tax')";
//echo $sql;die;
		$results=mysqli_query($connect,$sql);
		 
	
	if($results)
	echo "<script>alert('successfully inserted')</script>";

	else
		echo "<script>alert('Oops Something went wrong!')</script>";
	
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title> Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
<script type="text/javascript">
      $('select').selectpicker();
    </script>

<style>
  #myFileInput1 {
    display:none;
}
.pic_disp{
	height:100px;
	width:100px;
}
.rmv:before{content:"\f158";font-family:dashicons;display:block;position: relative;z-index: 1;background: #9d141b;color: #fff;border-radius: 30em;padding-top: 2px;width: 20px;height: 18px;float: right;top: 12px;text-align: center;cursor:pointer; pointer-events:auto;}
.upload_photo{width:58px;float:left;margin-right:20px;position:relative;}
.upload_photo:last-child{margin-right:0px;}
.upload_photo img{width:46px;height:46px;border:2px solid #fff;border-radius:3px;}
.mg{
	margin-top: 0px;
    font-size: 15px;
    font-weight: 600;
}
  </style>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    
    <!-- Sidebar menu-->
    <?php include_once('include/header.php')?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Add Billing</h1>
         
        </div>
		 
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Add Billing</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
			
	<form method="post" enctype="multipart/form-data">
      <div class="panel">
        <div class="panel-body">
          <h4 class="panel-title">Add New Billing</h4>
		  <p></p><p></p>
          <div class="row">
                <div class="col-sm-8">
				 <input type="text" placeholder="GEM/Unique No" title="GEM/Unique No" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips billing_no" name="billing_no" required >
				 </div> 
				  
              </div>
          </div>
		</div><p></p>
		 <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <select placeholder="Product name" title="Add Product" class="selectpicker" multiple data-live-search="true" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name" required >
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
                 </div>   
              </div>
          </div>
		</div><p></p>
	   
		 <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="number" placeholder="Supplied Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity" name="quantity" required >
                 </div>   
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="number" placeholder="Unit Price in rupees" title="Unit Price" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips price" name="price" required >
                 </div>   
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="text" placeholder="Tax" title="Tax" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips tax" name="tax" required >
                 </div>   
              </div>
          </div>
		</div>
		<p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-8">
				
                  <input type="file" placeholder="Upload" title="Upload" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips pic" name="pic" >
                 </div>   
              </div>
          </div>
		</div>
		<p></p>
		<p></p>
		
	   
		
		
		<input  type="submit" name="add_billing" class="btn btn-primary stock" value="Add New Billing">
	</form>
			</div>
          </div>
        </div>
      </div>
	 <?php include('include/footer.php')?> 
    </main>
	 <!-- Essential javascripts for application to work-->
    <script src=""></script>
    <script src="js/popper.min.js"></script>
    <script src=""></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    
</body>
</html>