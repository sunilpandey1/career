
<footer>
            <div class="footer">
               
               <div class="copyright">
                  <p>Copyright 2019 All Right Reserved By <a href="https://utechpl.com/">Uipropitome Tech</a></p>
               </div>
            
         </div>
         </footer>