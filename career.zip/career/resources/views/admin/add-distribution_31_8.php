<?php
session_start();
require_once('include/connection.php');
error_reporting(0);
if(empty($_SESSION['email']))
{
	echo "<script>window.location.href = 'login.php';</script>";
}

if(isset($_POST['add_distribution']))
{

	$product_name=$_POST['product_name'];
	$p_name=explode("??",$product_name);
	$p_id=$p_name[0];
	$prd_name=$p_name[1];
	$product_name1=$_POST['product_name1'];
	$p_name1=explode("??",$product_name1);
	$p_id1=$p_name1[0];
	$prd_name1=$p_name1[1];
	$product_name2=$_POST['product_name2'];
	$p_name2=explode("??",$product_name2);
	$p_id2=$p_name2[0];
	$prd_name2=$p_name2[1];
	$product_name3=$_POST['product_name3'];
	$p_name3=explode("??",$product_name3);
	$p_id3=$p_name3[0];
	$prd_name3=$p_name3[1];
	$product_name4=$_POST['product_name4'];
	$p_name4=explode("??",$product_name4);
	$p_id4=$p_name4[0];
	$prd_name4=$p_name4[1];
	$product_name5=$_POST['product_name5'];
	$p_name5=explode("??",$product_name5);
	$p_id5=$p_name5[0];
	$prd_name5=$p_name5[1];
	$product_name6=$_POST['product_name6'];
	$p_name6=explode("??",$product_name6);
	$p_id6=$p_name6[0];
	$prd_name6=$p_name6[1];
	$product_name7=$_POST['product_name7'];
	$p_name7=explode("??",$product_name7);
	$p_id7=$p_name7[0];
	$prd_name7=$p_name7[1];
	$product_name8=$_POST['product_name8'];
	$p_name8=explode("??",$product_name8);
	$p_id8=$p_name8[0];
	$prd_name8=$p_name8[1];
	$product_name9=$_POST['product_name9'];
	$p_name9=explode("??",$product_name9);
	$p_id9=$p_name9[0];
	$prd_name9=$p_name9[1];
	$product_name10=$_POST['product_name10'];
	$p_name10=explode("??",$product_name10);
	$p_id10=$p_name10[0];
	$prd_name10=$p_name10[1];
	$receiver_name=$_POST['receiver_name'];
	$quantity=$_POST['quantity'];
	$quantity1=$_POST['quantity1'];
	$quantity2=$_POST['quantity2'];
	$quantity3=$_POST['quantity3'];
	$quantity4=$_POST['quantity4'];
	$quantity5=$_POST['quantity5'];
	$quantity6=$_POST['quantity6'];
	$quantity7=$_POST['quantity7'];
	$quantity8=$_POST['quantity8'];
	$quantity9=$_POST['quantity9'];
	$quantity10=$_POST['quantity10'];
	$select="select * from main_stock where product_id='$p_id'";
	$sel_run=mysqli_query($connect,$select);
	
	if($quantity>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity)
				{
					$stk_quantity-=$quantity;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id','$prd_name','$receiver_name','$quantity')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		if($result)
			echo "<script>alert('successfully inserted')</script>";
		else
			echo "<script>alert('Oops Something went wrong!')</script>";

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
		}
	if($quantity1!="")
	{
		$select1="select * from main_stock where product_id='$p_id1'";
		
		$sel_run1=mysqli_query($connect,$select1);
		if($quantity1>0)
		{
		$quantity_result=mysqli_fetch_array($sel_run1);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity1)
				{
					$stk_quantity-=$quantity1;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id1','$prd_name1','$receiver_name','$quantity1')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id1'";
					//echo $upd_quantity;die;
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
	}
	if($quantity2!="")
	{
		$select="select * from main_stock where product_id='$p_id2'";
		$sel_run=mysqli_query($connect,$select);
		
	if($quantity2>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity2)
				{
					$stk_quantity-=$quantity2;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id2','$prd_name2','$receiver_name','$quantity2')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id2'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
	}
	if($quantity3!="")
	{	
	$select="select * from main_stock where product_id='$p_id3'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity3>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity3)
				{
					$stk_quantity-=$quantity3;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id3','$prd_name3','$receiver_name','$quantity3')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id3'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity4!="")
	{	
	$select="select * from main_stock where product_id='$p_id4'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity4>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity4)
				{
					$stk_quantity-=$quantity4;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id4','$prd_name4','$receiver_name','$quantity4')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id4'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity5!="")
	{	
	$select="select * from main_stock where product_id='$p_id5'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity5>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity5)
				{
					$stk_quantity-=$quantity5;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id5','$prd_name5','$receiver_name','$quantity5')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id5'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity6!="")
	{	
	$select="select * from main_stock where product_id='$p_id6'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity6>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity6)
				{
					$stk_quantity-=$quantity6;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id6','$prd_name6','$receiver_name','$quantity6')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id6'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity7!="")
	{	
	$select="select * from main_stock where product_id='$p_id7'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity3>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity7)
				{
					$stk_quantity-=$quantity7;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id7','$prd_name7','$receiver_name','$quantity7')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id7'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity8!="")
	{	
	$select="select * from main_stock where product_id='$p_id8'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity3>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity8)
				{
					$stk_quantity-=$quantity8;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id8','$prd_name8','$receiver_name','$quantity8')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id8'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity9!="")
	{	
	$select="select * from main_stock where product_id='$p_id9'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity9>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity9)
				{
					$stk_quantity-=$quantity9;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id9','$prd_name9','$receiver_name','$quantity9')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id9'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
	if($quantity10!="")
	{	
	$select="select * from main_stock where product_id='$p_id10'";
		$sel_run=mysqli_query($connect,$select);
	if($quantity10>0)
	{
		$quantity_result=mysqli_fetch_array($sel_run);
		
			$stk_quantity=$quantity_result['total_stock'];
			
			if($stk_quantity>0)
			{
				
				if($stk_quantity>=$quantity10)
				{
					$stk_quantity-=$quantity10;
					$sql="insert into distribution(product_id,product_name,receiver_name,quantity) values('$p_id10','$prd_name10','$receiver_name','$quantity10')";
		
					$result=mysqli_query($connect,$sql);
					$upd_quantity="update main_stock set total_stock='$stk_quantity' where product_id='$p_id10'";
					$upd_results=mysqli_query($connect,$upd_quantity);
					
				}
				else{
					echo "<script>alert('Quantity is out of stock!')</script>";
					
				}
				
				
			}
			
		
		
		

	}
	
	else{
					echo "<script>alert('Invalid Quantity!')</script>";
					
				}
					
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title> Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	
<style>
  #myFileInput1 {
    display:none;
}
.pic_disp{
	height:100px;
	width:100px;
}
.rmv:before{content:"\f158";font-family:dashicons;display:block;position: relative;z-index: 1;background: #9d141b;color: #fff;border-radius: 30em;padding-top: 2px;width: 20px;height: 18px;float: right;top: 12px;text-align: center;cursor:pointer; pointer-events:auto;}
.upload_photo{width:58px;float:left;margin-right:20px;position:relative;}
.upload_photo:last-child{margin-right:0px;}
.upload_photo img{width:46px;height:46px;border:2px solid #fff;border-radius:3px;}
.mg{
	margin-top: 0px;
    font-size: 15px;
    font-weight: 600;
}
.hide1,.hide2,.hide3,.hide4,.hide5,.hide6,.hide7,.hide8,.hide9,.hide10,.hide11,.hide12,.hide13,.hide14,.hide15{
	display:none;
}
  </style>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    
    <!-- Sidebar menu-->
    <?php include_once('include/header.php')?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Add Distribution</h1>
         
        </div>
		 
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Add Distribution</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
			
	<form method="post">
      <div class="panel">
        <div class="panel-body">
          <h4 class="panel-title">Add New Distribution</h4>
		  <a href="javascript:void(0)" style="float:right" class="nextdiv"><h4>Add New</h4></a><br/>
		  <p></p><p></p>
          <div class="row">
                <div class="col-sm-3">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name" required >
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				  <div class="col-sm-3 hide1" id="newpr1">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name1">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				 <div class="col-sm-3 hide2" id="newpr2">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name2">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div>
				  <div class="col-sm-3 hide3" id="newpr3">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name" name="product_name3">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				 
              </div>
			 
				  
              </div>
          </div>
		</div><p></p>
	   
		 <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-3">
				
                  <input type="text" placeholder="Receiver Name" title="Receiver Name" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips reciever_name" name="receiver_name" required >
                 </div>
				 <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity1 hide1" id="newq1" name="quantity1">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity2 hide2" id="newq2"  name="quantity2">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity3 hide3" id="newq3"  name="quantity3">
                 </div>
              </div>
          </div>
		</div><p></p>
		 <div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity" name="quantity" required >
                 </div>
					<div class="col-sm-3 hide4" id="newpr4">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name4" name="product_name4">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				 <div class="col-sm-3 hide5" id="newpr5">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name5" name="product_name5">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div>
				  <div class="col-sm-3 hide6" id="newpr6">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name6" name="product_name6">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-3">
				
                  <label class="form-control">Signature</label>
                 </div> 
					<div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity4 hide4" id="newq4" name="quantity4">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity5 hide5" id="newq5"  name="quantity5">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity6 hide6" id="newq6"  name="quantity6">
                 </div>
              </div>
          </div>
		</div><p></p>
		<div class="panel">
        <div class="panel-body">
          
		  
          <div class="row">
                <div class="col-sm-3 hide7" id="newpr7">
				<select placeholder="Product name "  title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name7" name="product_name7"  >
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				  <div class="col-sm-3 hide8" id="newpr8">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name8" name="product_name8">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				 <div class="col-sm-3 hide9" id="newpr9">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name9" name="product_name9">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div>
				  <div class="col-sm-3 hide10" id="newpr10">
				<select placeholder="Product name" title="Add Product" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips product_name10" name="product_name10">
                 <option value="">Select Product</option>
				<?php
					$prod="select * from product order by id desc";
					$prod_run=mysqli_query($connect,$prod);
					while($prod_result=mysqli_fetch_array($prod_run))
					{
				
				?>
                  <option value="<?php echo $prod_result['id']."??".$prod_result['product_name']?>"><?php echo $prod_result['product_name']?></option>
				<?php
					}
				?>
				 </select>
				 </div> 
				 
              </div>
			 
				  
              </div>
          </div>
		<p></p>
		<div class="panel">
        <div class="panel-body">
          <div class="row">
                 <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity4 hide7" id="newq7" name="quantity7">
                 </div> 
					<div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity4 hide8" id="newq8" name="quantity8">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity5 hide9" id="newq9"  name="quantity9">
                 </div>
				  <div class="col-sm-3">
				
                  <input type="number" placeholder="Quantity" title="Product Quantity" data-toggle="tooltip" data-trigger="hover" class="form-control tooltips quantity6 hide10" id="newq10"  name="quantity10">
                 </div>
              </div>
          </div>
		</div><p></p>
	   
		
		
		<input  type="submit" name="add_distribution" class="btn btn-primary stock" value="Add New Distribution">
	</form>
			</div>
          </div>
        </div>
      </div>
	   <?php include('include/footer.php')?>
    </main>
 <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
	<script>
	$(function() {
		var i=1;
		$(".nextdiv").click(function(){
			
			$("#newpr"+i).toggleClass("hide"+i);
			$("#newq"+i).toggleClass("hide"+i);
			i++;
		});
	});
	</script>
</body>
</html>	