<?php
		require_once("include/connection.php");
		$id=$_GET['id'];
		$select="select * from stock where id='$id'";
			$sel_run=mysqli_query($connect,$select);
			$sel_result=mysqli_fetch_array($sel_run);
			$pr_id=$sel_result['product_id'];
			$quantity=$sel_result['quantity'];
		$cat="delete from stock where id='$id'";
		$result=mysqli_query($connect,$cat);
		if($result)
		{
			
			$main="select * from main_stock where product_id='$pr_id'";
			$main_run=mysqli_query($connect,$main);
			$main_result=mysqli_fetch_array($main_run);
			$org_quantity=$main_result['total_stock'];
			$org_quantity-=$quantity;
			$upd="update main_stock set total_stock='$org_quantity' where product_id='$pr_id'";
			$upd_result=mysqli_query($connect,$upd);
			echo "<script>alert('deleted successfully')</script>";
			echo "<script>window.location.href='all-stock.php'</script>";
		}
			
?>