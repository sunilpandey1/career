<?php
		require_once("include/connection.php");
		$id=$_GET['id'];
		
		$cat="delete from billing where id='$id'";
		$result=mysqli_query($connect,$cat);
		if($result)
		{
			echo "<script>alert('deleted successfully')</script>";
			echo "<script>window.location.href='view-billing.php'</script>";
		}
			
?>