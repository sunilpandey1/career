<head>
    <title>Careers </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="{{ URL::asset('css/custom-bs.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('css/jquery.fancybox.min.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('css/bootstrap-select.min.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('css/owl.carousel.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ URL::asset('css/animate.min.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('css/style.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('fonts/icomoon/style.css') }}" type="text/css">
<link rel="stylesheet" href=" {{ URL::asset('fonts/line-icons/style.css') }}" type="text/css">	
   <!-- <link rel="stylesheet" href="css/custom-bs.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="fonts/line-icons/style.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">  --> 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="{{asset('css/mega-menu.css')}}">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
jQuery(document).ready(function(){
    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).stop().fadeIn("fast");
        },
        function() { $('.dropdown-menu', this).stop().fadeOut("fast");
    });
});
});
</script>	
  </head>