<header class="app-header"><a class="app-header__logo" href="index.php">Dashboard</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        
        <!--Notification Menu-->
        
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <!--<li><a class="dropdown-item" href="change-password.php"><i class="fa fa-user fa-lg"></i> Change Password</a></li>-->
            <li><a class="dropdown-item" href="<?php echo e(url('admin/signout')); ?>"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
	 <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        
      </div>
      <ul class="app-menu">
	 
        <li><a class="app-menu__item active" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Resources</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?php echo e(url('admin/resources')); ?>"><i class="icon fa fa-circle-o"></i> Add</a></li>
          <li><a class="treeview-item" href="<?php echo e(url('admin/view-resources')); ?>"><i class="icon fa fa-circle-o"></i> View</a></li>
           
          </ul>
        </li>
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Career Counselling</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?php echo e(url('admin/career-counselling')); ?>"><i class="icon fa fa-circle-o"></i> Add</a></li>
          <li><a class="treeview-item" href="<?php echo e(url('admin/view-career-counselling')); ?>"><i class="icon fa fa-circle-o"></i> View</a></li>
           
          </ul>
        </li>
		<!---<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Products</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="add-product.php"><i class="icon fa fa-circle-o"></i> Add Product</a></li>
            <li><a class="treeview-item" href="all-product.php"><i class="icon fa fa-circle-o"></i> All Product</a></li>
           
          </ul>
        </li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Stock</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="add-stock.php"><i class="icon fa fa-circle-o"></i> Add Stock</a></li>
			<li><a class="treeview-item" href="all-stock.php"><i class="icon fa fa-circle-o"></i> View Stock</a></li>
            <li><a class="treeview-item" href="total-stock.php"><i class="icon fa fa-circle-o"></i> All Stock</a></li>
          </ul>
        </li>
        
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file-text"></i><span class="app-menu__label">Billing Panel</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="add-billing.php"><i class="icon fa fa-circle-o"></i> Add Billing</a></li>
            <li><a class="treeview-item" href="view-billing.php"><i class="icon fa fa-circle-o"></i> View Billing</a></li>
            
          </ul>
        </li>
		
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file-text"></i><span class="app-menu__label">Distribution Panel</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="add-distribution.php"><i class="icon fa fa-circle-o"></i> Add</a></li>
            <li><a class="treeview-item" href="all-distribution.php"><i class="icon fa fa-circle-o"></i> All Distribution</a></li>
            
          </ul>
        </li>-->
	
      </ul>
    </aside>