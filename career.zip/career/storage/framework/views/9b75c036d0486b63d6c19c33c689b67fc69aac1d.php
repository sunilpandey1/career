<!doctype html>
<html lang="en">

<head>
  <title>Careers &mdash; Website Template by Colorlib</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="<?php echo e(asset('css/custom-bs.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/line-icons/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('css/mega-menu.css')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
jQuery(document).ready(function(){
    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).stop().fadeIn("fast");
        },
        function() { $('.dropdown-menu', this).stop().fadeOut("fast");
    });
});
}
</script>
<style>
.imgsize{
	width:300px;
	height:300px;
}
.spacesize{
	height:350px;
}
</style>
</head>

<body id="top">


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->


    <!-- NAVBAR -->
    <header class="site-navbar mt-3">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="site-logo col-6"><a href="index.html">Careers</a></div>

          <nav class="mx-auto site-navigation">
            <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
              <li><a href="index.html" class="nav-link">Home</a></li>
              <li><a href="job-listings.html">Job Listings</a></li>
              <li><a href="about.html">About</a></li>
              <li class="dropdown menu-large"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Resources</a>
			  <ul class="dropdown-menu megamenu row">
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header">Career Library</li>
                        <li><a href="<?php echo e(url('/resources','Actuarial Sciences')); ?>">Actuarial Sciences</a></li>
                        <li><a href="<?php echo e(url('/resources','Allied Medicine')); ?>">Allied Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Animation & Graphics')); ?>">Animation & Graphics</a></li>
                        <li><a href="<?php echo e(url('/resources','Applied Arts')); ?>">Applied Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Architecture')); ?>">Architecture</a></li>
                        <li><a href="<?php echo e(url('/resources','Aviation')); ?>">Aviation</a></li>
                        <li><a href="<?php echo e(url('/resources','Cabin Crew')); ?>">Cabin Crew</a></li>
						<li><a href="<?php echo e(url('/resources','Civil Services')); ?>">Civil Services</a></li>
                        <li><a href="<?php echo e(url('/resources','Commerce & Accounts')); ?>">Commerce & Accounts</a></li>
                        <li><a href="<?php echo e(url('/resources','Computer Application & IT')); ?>">Computer Application & IT</a></li>
                        <li><a href="<?php echo e(url('/resources','Defense')); ?>">Defense</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Design')); ?>">Design</a></li>
                        <li><a href="<?php echo e(url('/resources','Economics')); ?>">Economics</a></li>
                        <li><a href="<?php echo e(url('/resources','Engineering')); ?>">Engineering</a></li>
                        <li><a href="<?php echo e(url('/resources','Entrepreneurship')); ?>">Entrepreneurship</a></li>
                        <li><a href="<?php echo e(url('/resources','Ethical Hacking')); ?>">Ethical Hacking</a></li>
                        <li><a href="<?php echo e(url('/resources','Finance & Banking')); ?>">Finance & Banking</a></li>
						<li><a href="<?php echo e(url('/resources','Food & Agriculture')); ?>">Food & Agriculture</a></li>
                        <li><a href="<?php echo e(url('/resources','Hotel Management')); ?>">Hotel Management</a></li>
                        <li><a href="<?php echo e(url('/resources','Law')); ?>">Law</a></li>
                        <li><a href="<?php echo e(url('/resources','Life Science & Environment')); ?>">Life Science & Environment</a></li>
                        <li><a href="<?php echo e(url('/resources','Management')); ?>">Management</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Marketing & Advertising')); ?>">Marketing & Advertising</a></li>
                        <li><a href="<?php echo e(url('/resources','Maths & Statistics')); ?>">Maths & Statistics</a></li>
                        <li><a href="<?php echo e(url('/resources','Media & Communication')); ?>">Media & Communication</a></li>
                        <li><a href="<?php echo e(url('/resources','Medicine')); ?>">Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Merchant Navy')); ?>">Merchant Navy</a></li>
                        <li><a href="<?php echo e(url('/resources','Nutrition & Fitness')); ?>">Nutrition & Fitness</a></li>
						<li><a href="<?php echo e(url('/resources','Performing Arts')); ?>">Performing Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Physical Science')); ?>">Physical Science</a></li>
                        <li><a href="<?php echo e(url('/resources','Sales')); ?>">Sales</a></li>
                        <li><a href="<?php echo e(url('/resources','Social Sciences & Humanities')); ?>">Social Sciences & Humanities</a></li>
                       
                     </ul>
                  </li>
                  
               </ul>
			  </li>
              <li><a href="blog.html">Blog</a></li>
              <li class="d-lg-none"><a href="contact.html">Contact Us</a></li>
            </ul>
          </nav>

          <div class="right-cta-menu text-right d-flex aligin-items-center col-6">
            <div class="ml-auto">
              <a href="contact.html" class="btn btn-primary border-width-2 d-none d-lg-inline-block"><span
                  class="mr-2 icon-paper-plane"></span>Contact Us</a>
            </div>
            <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none mt-lg-2 ml-3"><span
                class="icon-menu h3 m-0 p-0 mt-2"></span></a>
          </div>

        </div>
      </div>
    </header>

    <!-- HOME -->
    <section class="home-section section-hero inner-page overlay bg-image"
      style="background-image: url('../images/hero_1.jpg');" id="home-section">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="mb-5 text-center">
              <h1 class="text-white font-weight-bold">Our Services</h1>
              <p>Find your dream jobs in our powerful career website template.</p>
            </div>
          </div>
        </div>
      </div>
    </section>


<section class="site-section services-section bg-light block__62849" id="next-section">
  <div class="container">
  
	<?php $__currentLoopData = $counselling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counsellings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="col-6 col-md-6 col-lg-12 mb-4 mb-lg-5">

	  <?php echo $counsellings->content; ?>

		 
      </div>  
    </div>
	<div class="row">
	<?php if($counsellings->image1!=""): ?>
		  <div class="col-4 col-md-4 spacesize">

		  <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image1)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image2!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		  <img class="imgsize"  src="<?php echo e(url('/images/'.$counsellings->image2)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image3!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		  <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image3)); ?>"></img>
			 
		  </div> 
    <?php endif; ?>		  
    </div>
	<div class="row">
	<?php if($counsellings->image4!=""): ?>
		  <div class="col-4 col-md-4 spacesize">

		 <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image4)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image5!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		 <img class="imgsize"  src="<?php echo e(url('/images/'.$counsellings->image5)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image6!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		 <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image6)); ?>"></img>
			 
		  </div> 
    <?php endif; ?>		  
    </div>
	<div class="row">
	<?php if($counsellings->image7!=""): ?>
		  <div class="col-4 col-md-4 spacesize">

		  <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image7)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image8!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		 <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image8)); ?>"></img>
			 
		  </div>  
	<?php endif; ?>	
	<?php if($counsellings->image9!=""): ?>	
		  <div class="col-4 col-md-4 spacesize">

		 <img class="imgsize"  src="<?php echo e(url('/images/'.$counsellings->image9)); ?>"></img>
			 
		  </div>
    <?php endif; ?>		  
    </div>
	<div class="row">
	<?php if($counsellings->image10!=""): ?>
		<div class="col-4 col-md-4 spacesize">

			 <img class="imgsize" src="<?php echo e(url('/images/'.$counsellings->image10)); ?>"></img>
				 
		  </div> 
    <?php endif; ?>		  
    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>

<section class="bg-white pt-5 testimony-full">

  <div class="owl-carousel single-carousel">


    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">
          <img class="img-fluid mx-auto" src="images/person_1.jpg" alt="Image">
          <blockquote>
            <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores
              repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
            <p><cite> &mdash; Richard Anderson</cite></p>
          </blockquote>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">
          <img class="img-fluid mx-auto" src="images/person_2.jpg" alt="Image">
          <blockquote>
            <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores
              repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
            <p><cite> &mdash; Chris Peters</cite></p>
          </blockquote>
        </div>
      </div>
    </div>

  </div>

</section>

<section class="py-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-8">
        <h2 class="text-white">Looking For A Job?</h2>
        <p class="mb-0 text-white lead">Lorem ipsum dolor sit amet consectetur adipisicing elit tempora adipisci
          impedit.</p>
      </div>
      <div class="col-md-3 ml-auto">
        <a href="#" class="btn btn-warning btn-block btn-lg">Sign Up</a>
      </div>
    </div>
  </div>
</section>

   <?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </div>

  <!-- SCRIPTS -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/isotope.pkgd.min.js"></script>
  <script src="js/stickyfill.min.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>

  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>


</body>

</html>