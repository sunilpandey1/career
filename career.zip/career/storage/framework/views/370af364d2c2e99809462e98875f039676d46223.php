<!doctype html>
<html lang="en">
  <?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body id="top">


<div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    

    <!-- NAVBAR -->
    <header class="site-navbar mt-3">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="site-logo col-6"><a href="index.html">Careers</a></div>

          <nav class="mx-auto site-navigation">
            <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
              <li><a href="index.html" class="nav-link active">Home</a></li>
              <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
			  <li class="dropdown menu-large"><a href="#" class="dropdown-toggle" data-toggle="dropdown">For Students</a>
			  <ul class="dropdown-menu megamenu row">
                  <li class="col-sm-6">
                     <ul>
                        <li class="dropdown-header font-weight-bold">Career Counseling Program </li>
                        <li><a href="<?php echo e(url('/career-counselling','classes 8-9')); ?>"><h4>Class 8-9</h4><strong> Stream & Subject Selection</strong>
						<p>Advanced assessment & personalised guidance to help you select the perfect stream and subjects that align you to the right careers.</p></a></li>
                        <li><a href="<?php echo e(url('/career-counselling','classes 10-12')); ?>"><h4>Class 10-12</h4><strong> Career Selection & Planning</strong>
							<p>Expert guidance & 5-dimensional assessment to help you discover your perfect career and choose the right course and college.</p>

						</a></li>
                        
                        
                     </ul>
                  </li>
                  <li class="col-sm-6">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/career-counselling','graduates and college students')); ?>"><h4>Graduates</h4><strong> Career Selection & Development</strong>
							<p>5-dimensional assessment & superior guidance to help you discover your perfect career and choose the best next step.</p></a></li>
                        
                        
                     </ul>
                  </li>
                  
                  
               </ul>
			  </li>
              <li class="dropdown menu-large"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Resources</a>
			  <ul class="dropdown-menu megamenu row">
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header">Career Library</li>
                        <li><a href="<?php echo e(url('/resources','Actuarial Sciences')); ?>">Actuarial Sciences</a></li>
                        <li><a href="<?php echo e(url('/resources','Allied Medicine')); ?>">Allied Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Animation & Graphics')); ?>">Animation & Graphics</a></li>
                        <li><a href="<?php echo e(url('/resources','Applied Arts')); ?>">Applied Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Architecture')); ?>">Architecture</a></li>
                        <li><a href="<?php echo e(url('/resources','Aviation')); ?>">Aviation</a></li>
                        <li><a href="<?php echo e(url('/resources','Cabin Crew')); ?>">Cabin Crew</a></li>
						<li><a href="<?php echo e(url('/resources','Civil Services')); ?>">Civil Services</a></li>
                        <li><a href="<?php echo e(url('/resources','Commerce & Accounts')); ?>">Commerce & Accounts</a></li>
                        <li><a href="<?php echo e(url('/resources','Computer Application & IT')); ?>">Computer Application & IT</a></li>
                        <li><a href="<?php echo e(url('/resources','Defense')); ?>">Defense</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Design')); ?>">Design</a></li>
                        <li><a href="<?php echo e(url('/resources','Economics')); ?>">Economics</a></li>
                        <li><a href="<?php echo e(url('/resources','Engineering')); ?>">Engineering</a></li>
                        <li><a href="<?php echo e(url('/resources','Entrepreneurship')); ?>">Entrepreneurship</a></li>
                        <li><a href="<?php echo e(url('/resources','Ethical Hacking')); ?>">Ethical Hacking</a></li>
                        <li><a href="<?php echo e(url('/resources','Finance & Banking')); ?>">Finance & Banking</a></li>
						<li><a href="<?php echo e(url('/resources','Food & Agriculture')); ?>">Food & Agriculture</a></li>
                        <li><a href="<?php echo e(url('/resources','Hotel Management')); ?>">Hotel Management</a></li>
                        <li><a href="<?php echo e(url('/resources','Law')); ?>">Law</a></li>
                        <li><a href="<?php echo e(url('/resources','Life Science & Environment')); ?>">Life Science & Environment</a></li>
                        <li><a href="<?php echo e(url('/resources','Management')); ?>">Management</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Marketing & Advertising')); ?>">Marketing & Advertising</a></li>
                        <li><a href="<?php echo e(url('/resources','Maths & Statistics')); ?>">Maths & Statistics</a></li>
                        <li><a href="<?php echo e(url('/resources','Media & Communication')); ?>">Media & Communication</a></li>
                        <li><a href="<?php echo e(url('/resources','Medicine')); ?>">Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Merchant Navy')); ?>">Merchant Navy</a></li>
                        <li><a href="<?php echo e(url('/resources','Nutrition & Fitness')); ?>">Nutrition & Fitness</a></li>
						<li><a href="<?php echo e(url('/resources','Performing Arts')); ?>">Performing Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Physical Science')); ?>">Physical Science</a></li>
                        <li><a href="<?php echo e(url('/resources','Sales')); ?>">Sales</a></li>
                        <li><a href="<?php echo e(url('/resources','Social Sciences & Humanities')); ?>">Social Sciences & Humanities</a></li>
                       
                     </ul>
                  </li>
                  
               </ul>
			  </li>
              <li><a href="blog.html">Blog</a></li>
              <li class="d-lg-none"><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
            </ul>
          </nav>
          
          <div class="right-cta-menu text-right d-flex aligin-items-center col-6">
            <div class="ml-auto">
              
			  <a href="<?php echo e(url('/contact')); ?>" class="btn btn-primary border-width-2 d-none d-lg-inline-block"><span class="mr-2 icon-paper-plane"></span>Contact Us</a>
			  <a href="<?php echo e(url('/login')); ?>" class="btn btn-primary border-width-2 d-none d-lg-inline-block"><span class="mr-2 icon-paper-plane"></span>Login</a>
            </div>
			
            <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none mt-lg-2 ml-3"><span class="icon-menu h3 m-0 p-0 mt-2"></span></a>
          </div>

        </div>
      </div>
    </header>

    <!-- HOME -->
    <section class="home-section section-hero overlay bg-image" style="background-image: url('images/hero_1.jpg');" id="home-section">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="mb-5 text-center">
              <h1 class="text-white font-weight-bold">A Powerful Career Website Template</h1>
              <p>Find your dream jobs in our powerful career website template.</p>
            </div>
            <form class="search-jobs-form">
              <div class="row mb-5">
			   <div class="col-md-4">
			   </div>
                <div class="col-md-4">
                  <input type="email" class="form-control form-control-lg" placeholder="Enter your email..." required style="height:100%">
                </div>
                
                <div class="col-md-4">
                  <a href="<?php echo e(url('/login')); ?>"><button type="button" class="btn btn-primary btn-lg btn-block text-white btn-search" style="width:50%"><span class="icon-search icon mr-2"></span>Subscribe</button></a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      
    </section>
    
    <section class="py-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2 text-white">Careers Statistics</h2>
            <p class="lead text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita unde officiis recusandae sequi excepturi corrupti.</p>
          </div>
        </div>
        <div class="row pb-0 block__19738 section-counter">

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="1930">0</strong>
            </div>
            <span class="caption">Candidates</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="54">0</strong>
            </div>
            <span class="caption">Jobs Posted</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="120">0</strong>
            </div>
            <span class="caption">Jobs Filled</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="550">0</strong>
            </div>
            <span class="caption">Companies</span>
          </div>

            
        </div>
      </div>
    </section>
<div class="container" id="myContainer">

   <div class="navbar">
      <div class="navbar-inner">
            <ul class="nav nav-pills">
             <li class="active"><a href="#step1" data-toggle="tab">For Students &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
             <li><a id="button" href="#step2" data-toggle="tab" >For Institutions&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
               <li><a href="#step3" data-toggle="tab">For Career Professional&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>

            </ul>
      </div>
   </div>
   <div class="tab-content">


      <div class="tab-pane fade in active" id="step1">
      <div class="row">
	  <div class="col-md-4">
	  <span style="color:red">Class 8-9</span><br/>
<p>Stream & Subject Selection</p>

<p>Discover your perfect stream, and subject combinations through a comprehensive assessment of your strengths and personalised counselling from leading career coaches. Gain from expert guidance and explore the right career opportunities aligned to your stream choice.</p>
	  </div>
	  <div class="col-md-4">
	 <span style="color:blue">Class 10-12</span>
<p>Career Selection & Planning<p/>

<p>Discover your perfect career based on your unique strengths & abilities, and get expert career counselling on your targeted career options to plan your course and college. Benefit from the exceptional support of our career counsellors and create a step-by-step plan for your career progression.<p/>
	  </div>
	  <div class="col-md-4">
	 <span style="color:green">Graduates</span>
<p>Career Selection & Development</p>

<p>Discover your next career move, accurately matched to your skills, interests and career goals through our comprehensive 5-dimensional assessment, and specialized career counselling. Accelerate your career through personalised guidance and all-round support from career counsellors.</p>
	  </div>
	  </div>
      </div>



      <div class="tab-pane fade" id="step2">

      <div class="row">
	  <div class="col-md-4">
	 <span style="color:blue"> In-School
Career Guidance Program</span>
<p>State-of-the-art career guidance platform with advanced assessments, expert counselling, in-school workshops, sophisticated analytics, alumni tracking and more, to set up an end-to-end career guidance ecosystem in schools and cater to the needs of multiple stakeholders.</p>
	  </div>
	  <div class="col-md-4">
	<span style="color:blue">MUN Training
Program</span>
<p>Prepare students for success at the Model United Nations through expert-led training and comprehensive guidance. Covering everything from delegation and resolution drafting to public speaking and chairing, the training program helps students excel at MUN conferences.</p>
	  </div>
	  <div class="col-md-4">
	<span style="color:blue"> Mindler
Talks</span>
<p>Drive career awareness and inspire students through interactive workshops with successful professionals. The best minds from eclectic fields like Economics, Science, Music, Cryptocurrency and more come together to share their experiences, knowledge and insights.</p>
	  </div>
	  </div>

      </div>
      <div class="tab-pane fade" id="step3">


      <div class="row">
	  <div class="col-md-6">
	 <span style="color:blue">International Certified
Career Coach (ICCC)</span>
<p>Enhance or build skills in career counselling through a 3-month career counselling certification program designed and delivered by industry experts. With an emphasis on global best practices and experiential learning, ICCC is the perfect stepping stone for educationists and counsellors.</p>
	  </div>
	  <div class="col-md-6">
	<span style="color:blue">Mindler Partner
Program</span>
<p>Be a Mindler Partner Counsellor to expand, enhance and grow your career counselling practice. Leverage a world-class assessment platform, advanced analytics and sophisticated counsellor support tools to deliver quality career guidance and grow as a career counsellor.</p>
	  </div>
	  
	  </div>
      </div>

   </div><!-- end tab content -->

</div>  <!-- end container -->

    

   <!-- <section class="site-section">
      <div class="container">

        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2">109,234 Job Listed</h2>
          </div>
        </div>
        

        <div class="mb-5">
          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-1.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-primary px-2 py-1 mb-3">Freelancer</span>
              <h2><a href="job-single.html">Dropbox Product Designer</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>Melbourn</h3>
              <span class="meta">Australia</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>

          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-2.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-warning px-2 py-1 mb-3">Full-time</span>
              <h2><a href="job-single.html">Creative Director in Intercom</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>London</h3>
              <span class="meta">United Kingdom</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>

          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-3.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-success px-2 py-1 mb-3">Part-time</span>
              <h2><a href="job-single.html">FullStack Developer in Shopify</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>London</h3>
              <span class="meta">United Kingdom</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>
          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-4.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-primary px-2 py-1 mb-3">Freelancer</span>
              <h2><a href="job-single.html">Dropbox Product Designer</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>Melbourn</h3>
              <span class="meta">Australia</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>
          
          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-5.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-warning px-2 py-1 mb-3">Full-time</span>
              <h2><a href="job-single.html">Creative Director in Intercom</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>London</h3>
              <span class="meta">United Kingdom</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>
          
          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-4.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-success px-2 py-1 mb-3">Part-time</span>
              <h2><a href="job-single.html">FullStack Developer in Shopify</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>London</h3>
              <span class="meta">United Kingdom</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>

          <div class="row align-items-start job-item border-bottom pb-3 mb-3 pt-3">
            <div class="col-md-2">
              <a href="job-single.html"><img src="images/featured-listing-3.jpg" alt="Image" class="img-fluid"></a>
            </div>
            <div class="col-md-4">
              <span class="badge badge-success px-2 py-1 mb-3">Part-time</span>
              <h2><a href="job-single.html">FullStack Developer in Shopify</a> </h2>
              <p class="meta">Publisher: <strong>John Stewart</strong> In: <strong>Design</strong></p>
            </div>
            <div class="col-md-3 text-left">
              <h3>London</h3>
              <span class="meta">United Kingdom</span>
            </div>
            <div class="col-md-3 text-md-right">
              <strong class="text-black">$60k &mdash; $100k</strong>
            </div>
          </div>

        </div>
        
        <div class="row pagination-wrap">
          
          <div class="col-md-6 text-center text-md-left">
            <div class="custom-pagination ml-auto">
              <a href="#" class="prev">Previous</a>
              <div class="d-inline-block">
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
              </div>
              <a href="#" class="next">Next</a>
            </div>
          </div>
        </div>

      </div>
    </section>-->

    

    
    <section class="site-section py-4 mb-5 border-top">
      <div class="container">
  
        <div class="row align-items-center">
          <div class="col-12 text-center mt-4 mb-5">
            <div class="row justify-content-center">
              <div class="col-md-7">
                <h2 class="section-title mb-2">Our Candidates Work In Company</h2>
                <p class="lead">Porro error reiciendis commodi beatae omnis similique voluptate rerum ipsam fugit mollitia ipsum facilis expedita tempora suscipit iste</p>
              </div>
            </div>
            
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_mailchimp.svg" alt="Image" class="img-fluid logo-1">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_paypal.svg" alt="Image" class="img-fluid logo-2">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_stripe.svg" alt="Image" class="img-fluid logo-3">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_visa.svg" alt="Image" class="img-fluid logo-4">
          </div>
        </div>
      </div>
    </section>


    <section class="bg-light pt-5 testimony-full">
        
        <div class="owl-carousel single-carousel">

        
          <div class="container">
            <div class="row">
              <div class="col-lg-6 mx-auto">
                <img class="img-fluid mx-auto" src="images/person_1.jpg" alt="Image">
                <blockquote>
                  <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
                  <p><cite> &mdash; Richard Anderson</cite></p>
                </blockquote>
              </div>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <div class="col-lg-6 mx-auto">
                <img class="img-fluid mx-auto" src="images/person_2.jpg" alt="Image">
                <blockquote>
                  <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
                  <p><cite> &mdash; Chris Peters</cite></p>
                </blockquote>
              </div>
            </div>
          </div>

      </div>

    </section>

    <section class="py-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h2 class="text-white">Looking For A Job?</h2>
            <p class="mb-0 text-white lead">Lorem ipsum dolor sit amet consectetur adipisicing elit tempora adipisci
              impedit.</p>
          </div>
          <div class="col-md-3 ml-auto">
            <a href="#" class="btn btn-warning btn-block btn-lg">Sign Up</a>
          </div>
        </div>
      </div>
    </section>
    
    <footer class="site-footer">

      
      <div class="container">
        <div class="row mb-5">
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Search Trending</h3>
            <ul class="list-unstyled">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Graphic Design</a></li>
              <li><a href="#">Web Developers</a></li>
              <li><a href="#">Python</a></li>
              <li><a href="#">HTML5</a></li>
              <li><a href="#">CSS3</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Company</h3>
            <ul class="list-unstyled">
              <li><a href="#">About Us</a></li>
              <li><a href="#">Career</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Resources</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Support</h3>
            <ul class="list-unstyled">
              <li><a href="#">Support</a></li>
              <li><a href="#">Privacy</a></li>
              <li><a href="#">Terms of Service</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Contact Us</h3>
            <div class="footer-social">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>
            </div>
          </div>
        </div>

        <div class="row text-center">
          <div class="col-12">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;
              <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i
                class="icon-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>
  
  </div>

    <!-- SCRIPTS -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/stickyfill.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    
    <script src="js/custom.js"></script>

     <script>
	 $(document).ready(function() {
		 /* $("#step1").show();
		 $("#step2").live('click', function(e) {
			 alert();
			$("#step1").hide(); 
		 });
		 $("#step3").click(function(e){
			$("#step1").hide(); 
		 }); */
});
	 </script>
  </body>
</html>