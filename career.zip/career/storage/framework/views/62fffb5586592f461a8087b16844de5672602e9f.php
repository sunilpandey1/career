<!doctype html>
<html lang="en">

<head>
  <title>Careers &mdash; Website Template by Colorlib</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="<?php echo e(asset('css/custom-bs.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/line-icons/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('css/mega-menu.css')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
jQuery(document).ready(function(){
    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).stop().fadeIn("fast");
        },
        function() { $('.dropdown-menu', this).stop().fadeOut("fast");
    });
});
}
</script>
<style>

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 30%;
  height: 300px;
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 22px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 0px 12px;
  border: 1px solid #ccc;
  width: 70%;
  border-left: none;
  height: 300px;
}
</style>
</head>

<body id="top">


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->


    <!-- NAVBAR -->
    <header class="site-navbar mt-3">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="site-logo col-6"><a href="index.html">Careers</a></div>

          <nav class="mx-auto site-navigation">
            <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
              <li><a href="index.html" class="nav-link">Home</a></li>
              <li><a href="job-listings.html">Job Listings</a></li>
              <li><a href="about.html">About</a></li>
              <li class="dropdown menu-large"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Resources</a>
			  <ul class="dropdown-menu megamenu row">
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header">Career Library</li>
                        <li><a href="<?php echo e(url('/resources','Actuarial Sciences')); ?>">Actuarial Sciences</a></li>
                        <li><a href="<?php echo e(url('/resources','Allied Medicine')); ?>">Allied Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Animation & Graphics')); ?>">Animation & Graphics</a></li>
                        <li><a href="<?php echo e(url('/resources','Applied Arts')); ?>">Applied Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Architecture')); ?>">Architecture</a></li>
                        <li><a href="<?php echo e(url('/resources','Aviation')); ?>">Aviation</a></li>
                        <li><a href="<?php echo e(url('/resources','Cabin Crew')); ?>">Cabin Crew</a></li>
						<li><a href="<?php echo e(url('/resources','Civil Services')); ?>">Civil Services</a></li>
                        <li><a href="<?php echo e(url('/resources','Commerce & Accounts')); ?>">Commerce & Accounts</a></li>
                        <li><a href="<?php echo e(url('/resources','Computer Application & IT')); ?>">Computer Application & IT</a></li>
                        <li><a href="<?php echo e(url('/resources','Defense')); ?>">Defense</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Design')); ?>">Design</a></li>
                        <li><a href="<?php echo e(url('/resources','Economics')); ?>">Economics</a></li>
                        <li><a href="<?php echo e(url('/resources','Engineering')); ?>">Engineering</a></li>
                        <li><a href="<?php echo e(url('/resources','Entrepreneurship')); ?>">Entrepreneurship</a></li>
                        <li><a href="<?php echo e(url('/resources','Ethical Hacking')); ?>">Ethical Hacking</a></li>
                        <li><a href="<?php echo e(url('/resources','Finance & Banking')); ?>">Finance & Banking</a></li>
						<li><a href="<?php echo e(url('/resources','Food & Agriculture')); ?>">Food & Agriculture</a></li>
                        <li><a href="<?php echo e(url('/resources','Hotel Management')); ?>">Hotel Management</a></li>
                        <li><a href="<?php echo e(url('/resources','Law')); ?>">Law</a></li>
                        <li><a href="<?php echo e(url('/resources','Life Science & Environment')); ?>">Life Science & Environment</a></li>
                        <li><a href="<?php echo e(url('/resources','Management')); ?>">Management</a></li>
                        
                     </ul>
                  </li>
                  <li class="col-sm-4">
                     <ul>
                        <li class="dropdown-header"></li>
                        <li><a href="<?php echo e(url('/resources','Marketing & Advertising')); ?>">Marketing & Advertising</a></li>
                        <li><a href="<?php echo e(url('/resources','Maths & Statistics')); ?>">Maths & Statistics</a></li>
                        <li><a href="<?php echo e(url('/resources','Media & Communication')); ?>">Media & Communication</a></li>
                        <li><a href="<?php echo e(url('/resources','Medicine')); ?>">Medicine</a></li>
                        <li><a href="<?php echo e(url('/resources','Merchant Navy')); ?>">Merchant Navy</a></li>
                        <li><a href="<?php echo e(url('/resources','Nutrition & Fitness')); ?>">Nutrition & Fitness</a></li>
						<li><a href="<?php echo e(url('/resources','Performing Arts')); ?>">Performing Arts</a></li>
                        <li><a href="<?php echo e(url('/resources','Physical Science')); ?>">Physical Science</a></li>
                        <li><a href="<?php echo e(url('/resources','Sales')); ?>">Sales</a></li>
                        <li><a href="<?php echo e(url('/resources','Social Sciences & Humanities')); ?>">Social Sciences & Humanities</a></li>
                       
                     </ul>
                  </li>
                  
               </ul>
			  </li>
              <li><a href="blog.html">Blog</a></li>
              <li class="d-lg-none"><a href="contact.html">Contact Us</a></li>
            </ul>
          </nav>

          <div class="right-cta-menu text-right d-flex aligin-items-center col-6">
            <div class="ml-auto">
              <a href="contact.html" class="btn btn-primary border-width-2 d-none d-lg-inline-block"><span
                  class="mr-2 icon-paper-plane"></span>Contact Us</a>
            </div>
            <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none mt-lg-2 ml-3"><span
                class="icon-menu h3 m-0 p-0 mt-2"></span></a>
          </div>

        </div>
      </div>
    </header>

    <!-- HOME -->
    <section class="home-section section-hero inner-page overlay bg-image"
      style="background-image: url('../images/hero_1.jpg');" id="home-section">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="mb-5 text-center">
              <h1 class="text-white font-weight-bold">Our Services</h1>
              <p>Find your dream jobs in our powerful career website template.</p>
            </div>
          </div>
        </div>
      </div>
    </section>


<section class="site-section services-section bg-light block__62849" id="next-section">
  <div class="container">

    <div class="row">
     
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">Summary</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Professional Opportunities</button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')">Career Path</button>
  <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">Leading Institutes</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Institutions Abroad</button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')">Entrance Exams</button>
</div>

<div id="London" class="tabcontent">
  <h3>UI Design</h3>
  <p>
Summary</br>

The User Interface (UI) designer's responsibility is to take care of the overall experience that visitors to a site will have. This will include layout, presentation, and navigation. Being a UI designer involves a great deal of interaction with marketing and other departments. UI designer works to present right corporate image. Your aesthetic skills and knowledge should be high. Your major role as a UI designer is to make sure that the site is clear, concise, and easy to use.

Career Opportunities in UI Design
Web/ App Development Companies
Online and Print Publishing Companies
Graphic Design Studios
Corporates - Marketing/ Corporate Communication
Advertising Companies
Freelancers</p>
</div>

<div id="Paris" class="tabcontent">
  <h3>Paris</h3>
  <p>Paris is the capital of France.</p> 
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>

<div id="Paris" class="tabcontent">
  <h3>Paris</h3>
  <p>Paris is the capital of France.</p> 
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>

<div id="Paris" class="tabcontent">
  <h3>Paris</h3>
  <p>Paris is the capital of France.</p> 
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   
      
      
     
      
      
    </div>


  </div>
</section>

<section class="bg-white pt-5 testimony-full">

  <div class="owl-carousel single-carousel">


    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">
          <img class="img-fluid mx-auto" src="images/person_1.jpg" alt="Image">
          <blockquote>
            <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores
              repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
            <p><cite> &mdash; Richard Anderson</cite></p>
          </blockquote>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">
          <img class="img-fluid mx-auto" src="images/person_2.jpg" alt="Image">
          <blockquote>
            <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores
              repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
            <p><cite> &mdash; Chris Peters</cite></p>
          </blockquote>
        </div>
      </div>
    </div>

  </div>

</section>

<section class="py-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-8">
        <h2 class="text-white">Looking For A Job?</h2>
        <p class="mb-0 text-white lead">Lorem ipsum dolor sit amet consectetur adipisicing elit tempora adipisci
          impedit.</p>
      </div>
      <div class="col-md-3 ml-auto">
        <a href="#" class="btn btn-warning btn-block btn-lg">Sign Up</a>
      </div>
    </div>
  </div>
</section>

    <footer class="site-footer">


      <div class="container">
        <div class="row mb-5">
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Search Trending</h3>
            <ul class="list-unstyled">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Graphic Design</a></li>
              <li><a href="#">Web Developers</a></li>
              <li><a href="#">Python</a></li>
              <li><a href="#">HTML5</a></li>
              <li><a href="#">CSS3</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Company</h3>
            <ul class="list-unstyled">
              <li><a href="#">About Us</a></li>
              <li><a href="#">Career</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Resources</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Support</h3>
            <ul class="list-unstyled">
              <li><a href="#">Support</a></li>
              <li><a href="#">Privacy</a></li>
              <li><a href="#">Terms of Service</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>Contact Us</h3>
            <div class="footer-social">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>
            </div>
          </div>
        </div>

        <div class="row text-center">
          <div class="col-12">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;
              <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made
              with <i class="icon-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com"
                target="_blank">Colorlib</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>

  </div>

  <!-- SCRIPTS -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/isotope.pkgd.min.js"></script>
  <script src="js/stickyfill.min.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>

  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>


</body>

</html>